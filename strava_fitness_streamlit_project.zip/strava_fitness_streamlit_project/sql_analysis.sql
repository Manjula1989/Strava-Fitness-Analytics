-- Fitness Analytics SQL Cleaning & Analysis
-- The Streamlit app executes the same cleaning concepts against the supplied CSV data.

-- 1) Daily activity cleaning
CREATE VIEW daily_activity AS
SELECT
    CAST(Id AS INTEGER) AS user_id,
    parse_date(ActivityDate) AS activity_date,
    CAST(TotalSteps AS INTEGER) AS total_steps,
    CAST(TotalDistance AS REAL) AS total_distance,
    CAST(VeryActiveDistance AS REAL) AS very_active_distance,
    CAST(ModeratelyActiveDistance AS REAL) AS moderately_active_distance,
    CAST(LightActiveDistance AS REAL) AS light_active_distance,
    CAST(VeryActiveMinutes AS INTEGER) AS very_active_minutes,
    CAST(FairlyActiveMinutes AS INTEGER) AS fairly_active_minutes,
    CAST(LightlyActiveMinutes AS INTEGER) AS lightly_active_minutes,
    CAST(SedentaryMinutes AS INTEGER) AS sedentary_minutes,
    CAST(Calories AS INTEGER) AS calories
FROM raw_daily_activity
WHERE Id IS NOT NULL AND ActivityDate IS NOT NULL;

-- 2) Average steps by weekday
SELECT
    CASE strftime('%w', activity_date)
      WHEN '0' THEN 'Sunday' WHEN '1' THEN 'Monday'
      WHEN '2' THEN 'Tuesday' WHEN '3' THEN 'Wednesday'
      WHEN '4' THEN 'Thursday' WHEN '5' THEN 'Friday'
      ELSE 'Saturday'
    END AS weekday,
    ROUND(AVG(total_steps), 0) AS avg_steps
FROM daily_activity
GROUP BY strftime('%w', activity_date)
ORDER BY ((CAST(strftime('%w', activity_date) AS INTEGER) + 6) % 7) + 1;

-- 3) Activity segmentation
SELECT
    CASE
      WHEN total_steps < 5000 THEN 'Low'
      WHEN total_steps < 10000 THEN 'Moderate'
      ELSE 'High'
    END AS activity_segment,
    COUNT(*) AS days,
    ROUND(AVG(total_steps),0) AS avg_steps,
    ROUND(AVG(calories),0) AS avg_calories
FROM daily_activity
GROUP BY activity_segment
ORDER BY avg_steps;

-- 4) Sleep and activity relationship
SELECT
    ROUND(AVG(a.total_steps),0) AS avg_steps,
    ROUND(AVG(s.minutes_asleep)/60.0,2) AS avg_sleep_hours,
    COUNT(*) AS matched_days
FROM daily_activity a
JOIN sleep s
  ON a.user_id = s.user_id
 AND a.activity_date = s.sleep_date
WHERE s.minutes_asleep IS NOT NULL;

-- 5) Highest-calorie days
SELECT activity_date, user_id, total_steps, total_distance, calories
FROM daily_activity
ORDER BY calories DESC
LIMIT 10;
