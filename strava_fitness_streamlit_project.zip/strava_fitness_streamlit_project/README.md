# Fitness Data Analytics — Streamlit + SQL

## Project goal
Build an interactive fitness analytics application from the supplied smart-device
fitness tracker data. The supplied case-study asks for:

- SQL-based data cleaning and insights
- A Streamlit dashboard
- SQL analysis inside the Streamlit app
- A recorded demonstration video

The case-study narrative in the supplied presentation is the Bellabeat wellness
technology case, although the presentation title says "STRAVA FITNESS DATA ANALYTICS
CASE-STUDY". This project follows the Bellabeat narrative.

## Folder structure

```text
strava_fitness_streamlit_project/
├── app.py
├── requirements.txt
├── sql_analysis.sql
├── README.md
└── data/
    ├── dailyActivity_merged.csv
    ├── dailyIntensities_merged.csv
    ├── dailyCalories_merged.csv
    ├── dailySteps_merged.csv
    ├── sleepDay_merged.csv
    ├── weightLogInfo_merged.csv
    ├── hourlySteps_merged.csv
    ├── hourlyCalories_merged.csv
    └── hourlyIntensities_merged.csv
```

## Run locally

```bash
cd strava_fitness_streamlit_project
python -m venv .venv

# Windows
.venv\Scripts\activate

pip install -r requirements.txt
streamlit run app.py
```

The app opens in the browser.

## Dashboard sections

1. Overview — KPI cards, daily steps, calories and weekday patterns
2. Activity — intensity and hourly activity
3. Sleep & Weight — sleep duration, time in bed and weight records
4. SQL Analysis — selectable SQL queries, results and CSV download
5. Data & Methodology — cleaning approach, limitations and table inventory

## SQL approach

The app loads the raw CSV files into an in-memory SQLite database and then creates
SQL analytical views. The SQL layer:

- standardises user IDs
- parses dates/times
- casts measures to numeric types
- removes rows without required identifiers/dates
- creates analysis-ready views
- joins activity and sleep by user ID and date

This keeps the SQL cleaning and SQL analysis visible inside the application.

## Suggested demo video flow

1. Introduce the case study and business question.
2. Show the project folder and data files.
3. Open the Streamlit dashboard.
4. Demonstrate the date and user filters.
5. Explain the KPI cards.
6. Show activity and hourly patterns.
7. Show sleep and weight analysis.
8. Open SQL Analysis and run 2–3 queries.
9. Explain the main insights and data limitations.
10. Finish with marketing-oriented implications for the Bellabeat case.

## Important limitation

The supplied tracker data is observational and represents the recorded sample only.
It should not be treated as a representative survey of all customers or as causal
evidence.
