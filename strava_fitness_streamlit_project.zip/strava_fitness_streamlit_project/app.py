
import os
from pathlib import Path
from datetime import datetime
import sqlite3
import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(
    page_title="Fitness Data Analytics",
    page_icon="🏃",
    layout="wide",
    initial_sidebar_state="expanded",
)

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"

st.markdown("""
<style>
.block-container {padding-top: 1.2rem; padding-bottom: 2rem;}
.metric-card {border:1px solid #e5e7eb; border-radius:12px; padding:12px;}
.small-note {color:#64748b; font-size:0.9rem;}
</style>
""", unsafe_allow_html=True)

@st.cache_resource
def get_connection():
    con = sqlite3.connect(":memory:", check_same_thread=False)
    def parse_date(value):
        if value is None:
            return None
        s = str(value).strip()
        for fmt in ("%m/%d/%Y", "%m/%d/%Y %I:%M:%S %p"):
            try:
                return datetime.strptime(s, fmt).strftime("%Y-%m-%d")
            except ValueError:
                pass
        return None
    def parse_hour(value):
        if value is None:
            return None
        s = str(value).strip()
        try:
            return datetime.strptime(s, "%m/%d/%Y %I:%M:%S %p").hour
        except ValueError:
            return None
    con.create_function("parse_date", 1, parse_date)
    con.create_function("parse_hour", 1, parse_hour)
    raw_files = {
        "raw_daily_activity": "dailyActivity_merged.csv",
        "raw_daily_intensities": "dailyIntensities_merged.csv",
        "raw_daily_calories": "dailyCalories_merged.csv",
        "raw_daily_steps": "dailySteps_merged.csv",
        "raw_sleep": "sleepDay_merged.csv",
        "raw_weight": "weightLogInfo_merged.csv",
        "raw_hourly_steps": "hourlySteps_merged.csv",
        "raw_hourly_calories": "hourlyCalories_merged.csv",
        "raw_hourly_intensities": "hourlyIntensities_merged.csv",
    }
    for table, filename in raw_files.items():
        pd.read_csv(DATA_DIR / filename).to_sql(table, con, index=False, if_exists="replace")
    sql = """
    CREATE VIEW daily_activity AS
    SELECT CAST(Id AS INTEGER) AS user_id,
           parse_date(ActivityDate) AS activity_date,
           CAST(TotalSteps AS INTEGER) AS total_steps,
           CAST(TotalDistance AS REAL) AS total_distance,
           CAST(VeryActiveDistance AS REAL) AS very_active_distance,
           CAST(ModeratelyActiveDistance AS REAL) AS moderately_active_distance,
           CAST(LightActiveDistance AS REAL) AS light_active_distance,
           CAST(VeryActiveMinutes AS INTEGER) AS very_active_minutes,
           CAST(FairlyActiveMinutes AS INTEGER) AS fairly_active_minutes,
           CAST(LightlyActiveMinutes AS INTEGER) AS lightly_active_minutes,
           CAST(SedentaryMinutes AS INTEGER) AS sedentary_minutes,
           CAST(Calories AS INTEGER) AS calories
    FROM raw_daily_activity WHERE Id IS NOT NULL AND ActivityDate IS NOT NULL;

    CREATE VIEW daily_intensities AS
    SELECT CAST(Id AS INTEGER) AS user_id,
           parse_date(ActivityDay) AS activity_date,
           CAST(SedentaryMinutes AS INTEGER) AS sedentary_minutes,
           CAST(LightlyActiveMinutes AS INTEGER) AS lightly_active_minutes,
           CAST(FairlyActiveMinutes AS INTEGER) AS fairly_active_minutes,
           CAST(VeryActiveMinutes AS INTEGER) AS very_active_minutes
    FROM raw_daily_intensities;

    CREATE VIEW sleep AS
    SELECT CAST(Id AS INTEGER) AS user_id,
           parse_date(SleepDay) AS sleep_date,
           CAST(TotalSleepRecords AS INTEGER) AS sleep_records,
           CAST(TotalMinutesAsleep AS INTEGER) AS minutes_asleep,
           CAST(TotalTimeInBed AS INTEGER) AS minutes_in_bed
    FROM raw_sleep;

    CREATE VIEW weight AS
    SELECT CAST(Id AS INTEGER) AS user_id,
           parse_date(Date) AS recorded_at,
           CAST(WeightKg AS REAL) AS weight_kg,
           CAST(Fat AS REAL) AS body_fat_pct,
           CAST(BMI AS REAL) AS bmi,
           CAST(IsManualReport AS INTEGER) AS is_manual
    FROM raw_weight;

    CREATE VIEW hourly_steps AS
    SELECT CAST(Id AS INTEGER) AS user_id,
           parse_date(ActivityHour) AS activity_date,
           parse_hour(ActivityHour) AS hour,
           CAST(StepTotal AS INTEGER) AS steps
    FROM raw_hourly_steps;

    CREATE VIEW hourly_calories AS
    SELECT CAST(Id AS INTEGER) AS user_id,
           parse_date(ActivityHour) AS activity_date,
           parse_hour(ActivityHour) AS hour,
           CAST(Calories AS INTEGER) AS calories
    FROM raw_hourly_calories;
    """
    con.executescript(sql)
    return con

con = get_connection()

@st.cache_data
def get_users():
    return con.execute("SELECT DISTINCT user_id FROM daily_activity ORDER BY user_id").df()["user_id"].tolist()

@st.cache_data
def get_date_range():
    return con.execute("SELECT MIN(activity_date), MAX(activity_date) FROM daily_activity").fetchone()

users = get_users()
min_date, max_date = get_date_range()

st.title("🏃 Fitness Data Analytics Dashboard")
st.caption("SQL-cleaned fitness tracker data | Interactive Streamlit dashboard")

with st.sidebar:
    st.header("Filters")
    user_choice = st.selectbox("User", ["All users"] + users)
    date_range = st.date_input(
        "Activity date range",
        value=(min_date, max_date),
        min_value=min_date,
        max_value=max_date,
    )
    if isinstance(date_range, tuple) and len(date_range) == 2:
        start_date, end_date = date_range
    else:
        start_date, end_date = min_date, max_date

def where_clause(alias="a"):
    conditions = [f"{alias}.activity_date BETWEEN '{start_date}' AND '{end_date}'"]
    if user_choice != "All users":
        conditions.append(f"{alias}.user_id = {int(user_choice)}")
    return " AND ".join(conditions)

where = where_clause("a")

overview = con.execute(f"""
SELECT
    COUNT(*) AS records,
    COUNT(DISTINCT user_id) AS users,
    ROUND(AVG(total_steps),0) AS avg_steps,
    ROUND(AVG(total_distance),2) AS avg_distance,
    ROUND(AVG(calories),0) AS avg_calories,
    ROUND(AVG(sedentary_minutes),0) AS avg_sedentary_minutes
FROM daily_activity a
WHERE {where}
""").df().iloc[0]

c1,c2,c3,c4,c5 = st.columns(5)
c1.metric("Activity records", f"{int(overview.records):,}")
c2.metric("Users", f"{int(overview.users):,}")
c3.metric("Avg steps/day", f"{int(overview.avg_steps):,}")
c4.metric("Avg distance/day", f"{overview.avg_distance:.2f}")
c5.metric("Avg calories/day", f"{int(overview.avg_calories):,}")

tab1, tab2, tab3, tab4, tab5 = st.tabs(
    ["📊 Overview", "🏃 Activity", "😴 Sleep & Weight", "🧮 SQL Analysis", "📋 Data & Methodology"]
)

with tab1:
    st.subheader("Daily activity trend")
    trend = con.execute(f"""
        SELECT activity_date, SUM(total_steps) AS total_steps,
               AVG(total_steps) AS avg_steps, AVG(calories) AS avg_calories
        FROM daily_activity a
        WHERE {where}
        GROUP BY activity_date ORDER BY activity_date
    """).df()
    if not trend.empty:
        fig = px.line(trend, x="activity_date", y="avg_steps", markers=True,
                      title="Average daily steps")
        fig.update_layout(yaxis_title="Steps", xaxis_title="")
        st.plotly_chart(fig, use_container_width=True)

        left,right = st.columns(2)
        with left:
            day = con.execute(f"""
                SELECT activity_date, AVG(calories) AS calories
                FROM daily_activity a WHERE {where}
                GROUP BY activity_date ORDER BY activity_date
            """).df()
            fig2 = px.area(day, x="activity_date", y="calories", title="Average daily calories")
            st.plotly_chart(fig2, use_container_width=True)
        with right:
            weekday = con.execute(f"""
                SELECT CASE strftime('%w', activity_date) WHEN '0' THEN 'Sunday' WHEN '1' THEN 'Monday' WHEN '2' THEN 'Tuesday' WHEN '3' THEN 'Wednesday' WHEN '4' THEN 'Thursday' WHEN '5' THEN 'Friday' ELSE 'Saturday' END AS weekday,
                       ((CAST(strftime('%w', activity_date) AS INTEGER) + 6) % 7) + 1 AS weekday_num,
                       ROUND(AVG(total_steps),0) AS avg_steps
                FROM daily_activity a WHERE {where}
                GROUP BY weekday, weekday_num ORDER BY weekday_num
            """).df()
            fig3 = px.bar(weekday, x="weekday", y="avg_steps", title="Average steps by weekday")
            st.plotly_chart(fig3, use_container_width=True)

with tab2:
    st.subheader("Activity intensity")
    intensity = con.execute(f"""
        SELECT activity_date,
               AVG(very_active_minutes) AS very_active,
               AVG(fairly_active_minutes) AS fairly_active,
               AVG(lightly_active_minutes) AS lightly_active,
               AVG(sedentary_minutes) AS sedentary
        FROM daily_activity a
        WHERE {where}
        GROUP BY activity_date ORDER BY activity_date
    """).df()
    if not intensity.empty:
        melted = intensity.melt(id_vars="activity_date", var_name="activity_level", value_name="minutes")
        fig = px.line(melted, x="activity_date", y="minutes", color="activity_level",
                      title="Daily activity minutes by intensity")
        st.plotly_chart(fig, use_container_width=True)

    hour = con.execute(f"""
        SELECT hour AS hour,
               AVG(steps) AS avg_steps
        FROM hourly_steps
        WHERE activity_date BETWEEN '{start_date}' AND '{end_date}'
        {f"AND user_id = {int(user_choice)}" if user_choice != "All users" else ""}
        GROUP BY hour ORDER BY hour
    """).df()
    fig = px.bar(hour, x="hour", y="avg_steps", title="Average steps by hour of day")
    fig.update_layout(xaxis_title="Hour", yaxis_title="Steps")
    st.plotly_chart(fig, use_container_width=True)

with tab3:
    st.subheader("Sleep analysis")
    sleep_where = f"s.sleep_date BETWEEN '{start_date}' AND '{end_date}'"
    if user_choice != "All users":
        sleep_where += f" AND s.user_id = {int(user_choice)}"
    sleep_df = con.execute(f"""
        SELECT sleep_date, AVG(minutes_asleep)/60.0 AS hours_asleep,
               AVG(minutes_in_bed)/60.0 AS hours_in_bed
        FROM sleep s
        WHERE {sleep_where}
        GROUP BY sleep_date ORDER BY sleep_date
    """).df()
    if sleep_df.empty:
        st.info("No sleep records are available for the selected filters.")
    else:
        avg_sleep = sleep_df.hours_asleep.mean()
        avg_bed = sleep_df.hours_in_bed.mean()
        a,b,c = st.columns(3)
        a.metric("Avg sleep", f"{avg_sleep:.2f} h")
        b.metric("Avg time in bed", f"{avg_bed:.2f} h")
        c.metric("Sleep records", f"{len(sleep_df):,}")
        fig = px.line(sleep_df, x="sleep_date", y=["hours_asleep","hours_in_bed"],
                      markers=True, title="Sleep duration vs time in bed")
        st.plotly_chart(fig, use_container_width=True)

    weight_where = f"date(w.recorded_at) BETWEEN '{start_date}' AND '{end_date}'"
    if user_choice != "All users":
        weight_where += f" AND w.user_id = {int(user_choice)}"
    weight_df = con.execute(f"""
        SELECT date(recorded_at) AS date, AVG(weight_kg) AS weight_kg, AVG(bmi) AS bmi
        FROM weight w WHERE {weight_where}
        GROUP BY date ORDER BY date
    """).df()
    if not weight_df.empty:
        fig = px.line(weight_df, x="date", y="weight_kg", markers=True, title="Recorded weight")
        st.plotly_chart(fig, use_container_width=True)

with tab4:
    st.subheader("SQL Analysis")
    st.caption("The queries below run directly against the SQL-cleaned SQLite views.")
    queries = {
        "1. Average steps by weekday": f"""
SELECT
    CASE strftime('%w', activity_date) WHEN '0' THEN 'Sunday' WHEN '1' THEN 'Monday' WHEN '2' THEN 'Tuesday' WHEN '3' THEN 'Wednesday' WHEN '4' THEN 'Thursday' WHEN '5' THEN 'Friday' ELSE 'Saturday' END AS weekday,
    ROUND(AVG(total_steps), 0) AS avg_steps
FROM daily_activity
WHERE {where_clause('daily_activity')}
GROUP BY weekday, ((CAST(strftime('%w', activity_date) AS INTEGER) + 6) % 7) + 1
ORDER BY ((CAST(strftime('%w', activity_date) AS INTEGER) + 6) % 7) + 1;
""",
        "2. Most active users": f"""
SELECT
    user_id,
    COUNT(*) AS activity_days,
    ROUND(AVG(total_steps),0) AS avg_steps,
    ROUND(AVG(calories),0) AS avg_calories
FROM daily_activity
WHERE activity_date BETWEEN '{start_date}' AND '{end_date}'
GROUP BY user_id
ORDER BY avg_steps DESC
LIMIT 10;
""",
        "3. Activity level segmentation": f"""
SELECT
    CASE
        WHEN total_steps < 5000 THEN 'Low'
        WHEN total_steps < 10000 THEN 'Moderate'
        ELSE 'High'
    END AS activity_segment,
    COUNT(*) AS days,
    ROUND(AVG(total_steps),0) AS avg_steps,
    ROUND(AVG(calories),0) AS avg_calories
FROM daily_activity
WHERE {where_clause('daily_activity')}
GROUP BY activity_segment
ORDER BY avg_steps;
""",
        "4. Sleep vs steps": f"""
SELECT
    ROUND(AVG(a.total_steps),0) AS avg_steps,
    ROUND(AVG(s.minutes_asleep)/60.0,2) AS avg_sleep_hours,
    COUNT(*) AS matched_days
FROM daily_activity a
JOIN sleep s
  ON a.user_id = s.user_id
 AND a.activity_date = s.sleep_date
WHERE {where}
  AND s.minutes_asleep IS NOT NULL;
""",
        "5. Highest calorie days": f"""
SELECT activity_date, user_id, total_steps, total_distance, calories
FROM daily_activity a
WHERE {where}
ORDER BY calories DESC
LIMIT 10;
""",
        "6. Hourly activity pattern": f"""
SELECT
    hour AS hour,
    ROUND(AVG(steps),0) AS avg_steps,
    ROUND(AVG(calories),0) AS avg_calories
FROM hourly_steps hs
JOIN hourly_calories hc
  ON hs.user_id = hc.user_id AND hs.activity_date = hc.activity_date AND hs.hour = hc.hour
WHERE hs.activity_date BETWEEN '{start_date}' AND '{end_date}'
  {f"AND hs.user_id = {int(user_choice)}" if user_choice != "All users" else ""}
GROUP BY hour
ORDER BY hour;
"""
    }
    selected = st.selectbox("Choose SQL analysis", list(queries.keys()))
    st.code(queries[selected], language="sql")
    result = con.execute(queries[selected]).df()
    st.dataframe(result, use_container_width=True, hide_index=True)
    st.download_button(
        "Download result as CSV",
        result.to_csv(index=False).encode("utf-8"),
        file_name="sql_analysis_result.csv",
        mime="text/csv"
    )

with tab5:
    st.subheader("Data & methodology")
    st.markdown("""
**Business context:** The case study asks the analyst to use smart-device fitness data
to understand consumer usage patterns and translate those findings into marketing insights.

**SQL cleaning layer**
- Standardises IDs as numeric user IDs.
- Converts date/time text into SQL DATE/TIMESTAMP fields.
- Casts measures such as steps, calories, distance and minutes into numeric types.
- Separates raw source views from cleaned analytical views.
- Joins activity and sleep data using user ID + date.

**Dashboard focus**
1. Daily activity and steps
2. Activity intensity and hourly patterns
3. Sleep and weight observations
4. Interactive SQL analysis

**Important data limitation:** This is observational tracker data from the supplied files.
It describes the sampled users and recorded behaviour; it should not be treated as a
representative survey of all customers or as causal evidence.

**Source note:** The supplied presentation is titled “STRAVA FITNESS DATA ANALYTICS
CASE-STUDY”, while the case-study narrative itself describes Bellabeat and its wellness
technology business. The dashboard follows the supplied Bellabeat case narrative.
""")
    st.subheader("Tables used")
    table_info = pd.DataFrame({
        "Table":["daily_activity","daily_intensities","daily_calories","daily_steps","sleep","weight","hourly_steps","hourly_calories","hourly_intensities"],
        "Purpose":["Daily activity KPIs","Intensity minutes","Daily calories","Daily step totals","Sleep duration","Weight/BMI records","Hourly steps","Hourly calories","Hourly intensity"]
    })
    st.dataframe(table_info, use_container_width=True, hide_index=True)

st.divider()
st.caption("Built with Streamlit + SQLite + SQL + Pandas + Plotly")
