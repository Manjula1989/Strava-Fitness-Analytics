# Initial data-driven observations

- Across the supplied daily activity records, average steps/day were 7,638, average calories were 2,304, average sedentary time was 991 minutes, and average very-active time was 21.2 minutes.
- Activity-day segmentation counts: High=303, Low=303, Moderate=334.
- The supplied sleep records average 6.99 hours asleep and 7.64 hours in bed.
- Top three hours by average recorded steps: 18:00 (599 steps), 19:00 (583 steps), 17:00 (550 steps).
